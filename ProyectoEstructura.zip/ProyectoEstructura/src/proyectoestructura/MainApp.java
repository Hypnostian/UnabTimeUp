package proyectoestructura;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.awt.Desktop;

public class MainApp extends JFrame {

    private static final String IMG_ROOT = "/images/";

    private final ResponsiveLabel textoCentralLabel;
    private final ResponsiveLabel bannerLabel;

    public MainApp() {
        setTitle("Unab TimeUp");
        setMinimumSize(new Dimension(1024, 640));
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);

        /* Zona central */
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Color.WHITE);
        add(center, BorderLayout.CENTER);

        JPanel inner = new JPanel(null);
        inner.setOpaque(false);
        center.add(inner, BorderLayout.CENTER);

        textoCentralLabel = new ResponsiveLabel(IMG_ROOT + "texto_central.png", 800, 450);
        bannerLabel = new ResponsiveLabel(IMG_ROOT + "Banner.png", 780, 560);
        inner.add(textoCentralLabel);
        inner.add(bannerLabel);

        inner.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                if (inner.getWidth() > 0 && inner.getHeight() > 0) {
                    placeCenterImages(inner.getSize());
                }
            }
        });

        add(buildFooter(), BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    /* ---------------- Encabezado ---------------- */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245, 245, 245));

        // Logos
        JLabel logo = new JLabel(loadScaled(IMG_ROOT + "logo_inferior.png", 120, 120));
        JLabel logito = new JLabel(loadScaled(IMG_ROOT + "logito_1.png", 240, 110));
        JPanel logoBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 15));
        logoBox.setOpaque(false);
        logoBox.add(logo);
        logoBox.add(logito);
        header.add(logoBox, BorderLayout.WEST);

        // Botonera
        String[] names = {"¿Qué es TimeUp?", "Canales", "Bienestar Unab", "Inicio sesión"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER, 28, 20));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif", Font.BOLD, 16));
            b.setBackground(new Color(240, 240, 240));
            b.setPreferredSize(new Dimension(180, 48));
            b.setBorder(new LineBorder(new Color(220, 220, 220), 1, true));
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        // Modo oscuro icon
        JLabel dark = new JLabel(loadScaled(IMG_ROOT + "modo_oscuro.png", 56, 56));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 22, 12));
        right.setOpaque(false);
        right.add(dark);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    /* ---------------- Footer ---------------- */
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245, 245, 245));

        JLabel logoInf = new JLabel(loadScaled(IMG_ROOT + "logo_inferior.png", 80, 80));
        JTextArea legal = new JTextArea("©2025 Universidad Autónoma de Bucaramanga - UNAB |\n"
                + "Sujeta a inspección y vigilancia por parte del Ministerio de Educación Nacional. Resolución 3284 (21 diciembre de 1956)");
        legal.setFont(new Font("SansSerif", Font.PLAIN, 12));
        legal.setOpaque(false);
        legal.setEditable(false);
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        left.setOpaque(false);
        left.add(logoInf);
        left.add(legal);
        footer.add(left, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1, 2, 120, 0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes", "https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales", "https://unab.edu.co/innova/recursos-y-ayudas-profesores/?_ga=2.181"},
            {"Repositorio UNAB", "https://repository.unab.edu.co"},
            {"Sistema de bibliotecas UNAB", "https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube", "https://www.youtube.com/@unabeduco"},
            {"Linkedin", "https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter", "https://x.com/unab_online"},
            {"Instagram", "https://www.instagram.com/unab_online/?hl=es"},
            {"Facebook", "https://www.facebook.com/unab.online/?locale=es_LA"}
        }));
        footer.add(cols, BorderLayout.CENTER);
        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans", Font.BOLD, 14));
        t.setForeground(new Color(164, 164, 164));
        col.add(t);
        col.add(Box.createVerticalStrut(12));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans", Font.BOLD, 16));
            l.setForeground(new Color(164, 164, 164));
            l.setCursor(new Cursor(Cursor.HAND_CURSOR));
            String url = d[1];
            l.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    open(url);
                }

                public void mouseEntered(java.awt.event.MouseEvent e) {
                    l.setForeground(new Color(120, 120, 120));
                }

                public void mouseExited(java.awt.event.MouseEvent e) {
                    l.setForeground(new Color(164, 164, 164));
                }
            });
            col.add(l);
        }
        return col;
    }

    /* ---------------- Posicionamiento adaptable ---------------- */
    private void placeCenterImages(Dimension s) {
        int w = s.width, h = s.height;
        if (w == 0 || h == 0) {
            return;
        }
        int textoW = (int) (w * 0.45), bannerW = (int) (w * 0.40);
        textoCentralLabel.resizeTo(textoW);
        bannerLabel.resizeTo(bannerW);
        int y = h / 2;
        textoCentralLabel.setLocation((int) (w * 0.05), y - textoCentralLabel.getHeight() / 2);
        bannerLabel.setLocation(w - bannerLabel.getWidth() - (int) (w * 0.05), y - bannerLabel.getHeight() / 2);
    }

    /* ---------------- ResponsiveLabel ---------------- */
    private static class ResponsiveLabel extends JLabel {

        private final BufferedImage orig;
        private final int natW, natH;

        ResponsiveLabel(String path, int natW, int natH) {
            this.natW = natW;
            this.natH = natH;
            this.orig = loadBuffered(path);
            resizeTo(natW);
        }

        void resizeTo(int targetW) {
            if (targetW <= 0) {
                targetW = 1;
            }
            int targetH = (int) ((double) targetW / natW * natH);
            setIcon(new ImageIcon(orig.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH)));
            setSize(targetW, targetH);
        }

        private static BufferedImage loadBuffered(String p) {
            try (InputStream is = MainApp.class.getResourceAsStream(p)) {
                return ImageIO.read(is);
            } catch (Exception e) {
                return new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
            }
        }
    }

    /* ---------------- Utilidades ---------------- */
    private ImageIcon loadScaled(String path, int w, int h) {
        try (InputStream is = getClass().getResourceAsStream(path)) {
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH));
        } catch (IOException e) {
            return new ImageIcon();
        }
    }

    private void open(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ignored) {
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainApp::new);
    }
}
