package proyectoestructura;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class LoginFrame extends JFrame {

    /* ─────────── Credenciales de prueba ─────────── */
    private static final String USER_TEST = "admin";
    private static final String PASS_TEST = "0000";

    /* ─────────── Config ─────────── */
    private static final int FRAME_W = 1360;
    private static final int FRAME_H = 768;
    private static final int RIGHT_W = 540;

    private static final String LOGO_PATH = "/images/logo.png";
    private static final String UTU_PATH  = "/images/utu.png";
    private static final String ETU_PATH  = "/images/ETU.png";

    private static final Color ORANGE  = Color.decode("#F69C00");
    private static final Color GRAY_TX = Color.decode("#9E9E9E");
    private static final Color GRAY_BG = Color.decode("#E2E2E2");

    private static final int LOGO_W = 180, LOGO_H = 200;
    private static final int UTU_W  = 450, UTU_H  = 240;
    private static final int ETU_W  = 455, ETU_H  = 200;

    public LoginFrame() {
        super("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(FRAME_W, FRAME_H);
        setResizable(false);
        setLocationRelativeTo(null);
        buildUI();
    }

    /* ─────────── Build UI ─────────── */
    private void buildUI() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setDividerSize(0);
        split.setEnabled(false);
        split.setDividerLocation(FRAME_W - RIGHT_W);
        getContentPane().add(split);

        /* LEFT */
        JPanel left = new JPanel(new GridBagLayout());
        left.setBackground(Color.WHITE);
        split.setLeftComponent(left);

        JLabel logo = new JLabel(loadIcon(LOGO_PATH, LOGO_W, LOGO_H));
        JLabel utu  = new JLabel(loadIcon(UTU_PATH, UTU_W, UTU_H));

        JPanel hbox = new JPanel();
        hbox.setOpaque(false);
        hbox.setLayout(new BoxLayout(hbox, BoxLayout.X_AXIS));
        hbox.add(logo);
        hbox.add(Box.createRigidArea(new Dimension(25, 0)));
        hbox.add(utu);
        left.add(hbox);

        /* RIGHT */
        JPanel right = new JPanel();
        right.setPreferredSize(new Dimension(RIGHT_W, FRAME_H));
        right.setBackground(GRAY_BG);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        split.setRightComponent(right);

        right.add(Box.createVerticalGlue());

        JLabel titleImg = new JLabel(loadIcon(ETU_PATH, ETU_W, ETU_H));
        titleImg.setAlignmentX(Component.CENTER_ALIGNMENT);
        right.add(titleImg);
        right.add(Box.createVerticalStrut(40));

        JTextField user = new JTextField("Nombre Usuario");
        styliseField(user, "Nombre Usuario");
        right.add(user);
        right.add(Box.createVerticalStrut(22));

        JPasswordField pass = new JPasswordField("Contraseña");
        styliseField(pass, "Contraseña");
        right.add(pass);
        right.add(Box.createVerticalStrut(38));

        JButton loginBtn = new JButton("Ingresar");
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setBackground(ORANGE);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(loadFont(Font.BOLD, 22f));
        loginBtn.setFocusPainted(false);
        loginBtn.setPreferredSize(new Dimension(340, 60));
        loginBtn.setMaximumSize(new Dimension(340, 60));
        right.add(loginBtn);
        right.add(Box.createVerticalStrut(28));

        JLabel forgot = new JLabel("¿Olvidaste tu contraseña?", SwingConstants.CENTER);
        forgot.setAlignmentX(Component.CENTER_ALIGNMENT);
        forgot.setForeground(GRAY_TX);
        forgot.setFont(loadFont(Font.PLAIN, 15f));
        right.add(forgot);

        right.add(Box.createVerticalGlue());

        /* ------- Acción de login ------- */
        loginBtn.addActionListener(e -> {
            String u = user.getText().trim();
            String p = new String(pass.getPassword()).trim();
            if (u.equals(USER_TEST) && p.equals(PASS_TEST)) {
                dispose();                       // cerrar login
                SwingUtilities.invokeLater(MainApp::new); // abrir pantalla principal
            } else {
                JOptionPane.showMessageDialog(this,
                        "Credenciales incorrectas",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /* Helpers */
    private ImageIcon loadIcon(String path, int w, int h) {
        try (InputStream is = getClass().getResourceAsStream(path)) {
            if (is == null) throw new IOException("Recurso no encontrado: " + path);
            BufferedImage img = ImageIO.read(is);
            Image scaled = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
            return new ImageIcon();
        }
    }

    private Font loadFont(int style, float size) {
        try (InputStream is = getClass().getResourceAsStream("/fonts/OpenSans-Regular.ttf")) {
            if (is != null) {
                Font f = Font.createFont(Font.TRUETYPE_FONT, is);
                return f.deriveFont(style, size);
            }
        } catch (Exception ignored) {}
        return new Font("SansSerif", style, (int) size);
    }

    private void styliseField(JTextComponent field, String placeholder) {
        field.setFont(loadFont(Font.PLAIN, 18f));
        field.setMaximumSize(new Dimension(420, 52));
        field.setPreferredSize(new Dimension(420, 52));
        field.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Centrar texto solo si es JTextField o JPasswordField
        if (field instanceof JTextField) {
            ((JTextField) field).setHorizontalAlignment(SwingConstants.CENTER);
        } else if (field instanceof JPasswordField) {
            ((JPasswordField) field).setHorizontalAlignment(SwingConstants.CENTER);
        }

        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(10, 14, 10, 14)));
        field.setForeground(Color.GRAY);

        if (field instanceof JPasswordField) ((JPasswordField) field).setEchoChar((char) 0);

        field.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                    if (field instanceof JPasswordField)
                        ((JPasswordField) field).setEchoChar('\u2022');
                }
            }
            @Override public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(Color.GRAY);
                    if (field instanceof JPasswordField)
                        ((JPasswordField) field).setEchoChar((char) 0);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
