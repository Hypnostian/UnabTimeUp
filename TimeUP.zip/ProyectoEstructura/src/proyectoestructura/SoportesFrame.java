package proyectoestructura;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class SoportesFrame {

    public SoportesFrame() {
        try {
            Desktop.getDesktop().browse(new URI("https://unab.edu.co/contactanos/"));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    void setVisible(boolean b) {
    }
}

