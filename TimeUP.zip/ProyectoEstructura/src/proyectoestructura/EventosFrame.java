package proyectoestructura;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import proyectoestructura.ThemeManager;

public class EventosFrame extends JFrame {

    private static final String IMG_ROOT = "/images/";
    private static final String JSON_PATH = "/resources/eventos.json";
    private static final Color ORANGE = new Color(0xF6, 0x9C, 0x00);
    private static final int TOTAL_HOURS = 96;
    private static final int CURRENT_HOURS = 76;

    private JPanel eventsContainer, sideBar;
    private JSplitPane splitPane;
    private JButton notiBtn;
    private final List<JButton> sidebarButtons = new ArrayList<>();
    private final Map<Event, JCheckBox> notificationMap = new LinkedHashMap<>();
    private List<Event> allEvents;

    public EventosFrame() {
        super("Eventos - Unab TimeUp");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1280, 720);
        setMinimumSize(new Dimension(1024, 640));
        setLayout(new BorderLayout());

        try {
            loadEvents();
        } catch (Exception e) {
            e.printStackTrace();
            allEvents = Arrays.asList(
                new Event("Festival de Talento UNAB", "23 de mayo de 2024", "3:00 – 5:00 pm",
                          "Auditorio Menor Alfonso Gómez Gómez",
                          "Celebra el arte y la creatividad estudiantil...", "Cultural", 2),
                new Event("Exposición de Arte Estudiantil", "10 de mayo de 2024", "3:00 – 5:00 pm",
                          "Galería de Arte UNAB",
                          "Muestra de las obras visuales...", "Cultural", 2)
            );
        }

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
        // recarga el contador de notificaciones al arrancar el frame
        updateBadge();

        // aplica el tema inicial según el estado en ThemeManager
        boolean dark = ThemeManager.isDarkMode();
        Color bg = dark ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = dark ? Color.WHITE        : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                adjustSidebarButtons();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
        SwingUtilities.invokeLater(this::adjustSidebarButtons);
    }

    private void loadEvents() throws IOException {
        InputStream is = getClass().getResourceAsStream(JSON_PATH);
        if (is == null) {
            throw new FileNotFoundException("No se encontró: " + JSON_PATH);
        }
        try (Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            Gson gson = new Gson();
            java.lang.reflect.Type listType = new TypeToken<List<TempEvent>>() {}.getType();
            List<TempEvent> temp = gson.fromJson(r, listType);
            allEvents = temp.stream().map(te ->
                new Event(te.titulo, te.fecha, te.hora, te.lugar, te.descripcion, te.categoria, te.duracion)
            ).collect(Collectors.toList());
        }
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245, 245, 245));

        JPanel west = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        west.setOpaque(false);
        west.add(new JLabel(loadScaled("logo_inferior.png", 100, 100)));
        west.add(new JLabel(loadScaled("logito_1.png", 200, 90)));
        header.add(west, BorderLayout.WEST);

        String[] names = {"Inicio", "Eventos", "Historial", "Mi agenda", "Soportes"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif", Font.BOLD, 14));
            b.setPreferredSize(new Dimension(140, 40));
            b.setBackground(new Color(240, 240, 240));
            b.setBorder(new LineBorder(new Color(200, 200, 200), 1, true));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setFocusPainted(false);
            switch (n) {
                case "Inicio":
                    b.addActionListener(e -> { new InicioFrame().setVisible(true); dispose(); });
                    break;
                case "Eventos":
                    b.setEnabled(false);
                    break;
                case "Historial":
                    b.addActionListener(e -> { new HistorialFrame().setVisible(true); dispose(); });
                    break;
                case "Mi agenda":
                    b.addActionListener(e -> { new MiAgendaFrame().setVisible(true); dispose(); });
                    break;
                case "Soportes":
                    b.addActionListener(e -> { new SoportesFrame().setVisible(true); dispose(); });
                    break;
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
        right.setOpaque(false);

        notiBtn = new JButton("\uD83D\uDD14 0");
        notiBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        notiBtn.setForeground(ORANGE.darker());
        notiBtn.setContentAreaFilled(false);
        notiBtn.setBorder(null);
        notiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notiBtn.addActionListener(e -> showNotifications());
        right.add(notiBtn);

        JButton profile = new JButton(loadScaled("perfil.png", 30, 30));
        profile.setContentAreaFilled(false);
        profile.setBorder(null);
        profile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        profile.addActionListener(e -> { new PerfilFrame().setVisible(true); dispose(); });
        right.add(profile);

        JButton darkBtn = new JButton(loadScaled("modo_oscuro.png", 30, 30));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e -> toggleDarkMode());
        right.add(darkBtn);

        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JSplitPane buildCenter() {
        sideBar = new JPanel();
        sideBar.setBackground(new Color(245, 245, 245));
        sideBar.setLayout(new BoxLayout(sideBar, BoxLayout.Y_AXIS));
        sideBar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        sideBar.setPreferredSize(new Dimension(140, 0));

        String[] icons = {"cultural.png", "deportes.png", "salud.png", "interes.png"};
        String[] cats = {"Cultural", "Deportivos", "Salud", "De Interes"};
        for (int i = 0; i < icons.length; i++) {
            JButton btn = new JButton(loadScaled(icons[i], 120, 40));
            btn.setToolTipText(cats[i]);
            btn.setContentAreaFilled(false);
            btn.setBorderPainted(false);
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            final String cat = cats[i];
            btn.addActionListener(e -> filterByCategory(cat));
            sidebarButtons.add(btn);
            sideBar.add(btn);
            sideBar.add(Box.createVerticalStrut(15));
        }
        sideBar.add(Box.createVerticalGlue());

        JButton sim = new JButton("Simulador");
        sim.setFont(new Font("SansSerif", Font.BOLD, 14));
        sim.setBackground(Color.WHITE);
        sim.setOpaque(true);
        sim.setBorder(new LineBorder(new Color(200, 200, 200), 1, true));
        sim.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sim.addActionListener(e -> showSimulatorDialog());
        sidebarButtons.add(sim);
        sideBar.add(sim);

        eventsContainer = new JPanel();
        eventsContainer.setLayout(new BoxLayout(eventsContainer, BoxLayout.Y_AXIS));
        eventsContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        updateEvents(allEvents);

        JScrollPane scroll = new JScrollPane(eventsContainer);
        scroll.setBorder(null);

        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sideBar, scroll);
        splitPane.setDividerLocation(sideBar.getPreferredSize().width + 20);
        splitPane.setEnabled(false);
        splitPane.setResizeWeight(0);
        return splitPane;
    }

    private void adjustSidebarButtons() {
        int sideW = sideBar.getPreferredSize().width;
        for (JButton btn : sidebarButtons) {
            Icon ic = btn.getIcon();
            if (ic instanceof ImageIcon) {
                int ih = ((ImageIcon) ic).getIconHeight();
                btn.setPreferredSize(new Dimension(sideW, ih + 20));
                btn.setMaximumSize(new Dimension(sideW, ih + 20));
            } else {
                btn.setPreferredSize(new Dimension(sideW, 50));
                btn.setMaximumSize(new Dimension(sideW, 50));
            }
        }
        sideBar.revalidate();
        splitPane.setDividerLocation(sideW + 20);
    }

    private void filterByCategory(String cat) {
        updateEvents(allEvents.stream()
            .filter(ev -> ev.category.equals(cat))
            .collect(Collectors.toList()));
    }

    private void updateEvents(List<Event> list) {
        eventsContainer.removeAll();
        notificationMap.clear();
        for (Event ev : list) {
            eventsContainer.add(createEventCard(ev));
            eventsContainer.add(Box.createVerticalStrut(10));
        }
        eventsContainer.revalidate();
        eventsContainer.repaint();
        updateBadge();
    }

    private JPanel createEventCard(Event ev) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new LineBorder(new Color(220, 220, 220), 1, true));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        JPanel dateP = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(ORANGE);
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        dateP.setOpaque(false);
        dateP.setPreferredSize(new Dimension(100, 140));
        dateP.setMinimumSize(new Dimension(100, 140));
        dateP.setMaximumSize(new Dimension(100, 140));
        JLabel dateLbl = new JLabel("<html><center>" + ev.date + "</center></html>", SwingConstants.CENTER);
        dateLbl.setForeground(Color.WHITE);
        dateLbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        dateP.add(dateLbl, BorderLayout.CENTER);
        card.add(dateP, BorderLayout.WEST);

        JLabel title = new JLabel(ev.title);
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        JButton moreBtn = new JButton(loadScaled("vermas.png", 100, 60));
        moreBtn.setContentAreaFilled(false);
        moreBtn.setBorder(null);
        moreBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        moreBtn.addActionListener(e -> showDetailDialog(ev));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(title, BorderLayout.WEST);
        top.add(moreBtn, BorderLayout.EAST);
        card.add(top, BorderLayout.CENTER);

        JCheckBox cb = new JCheckBox();
        cb.setSelected(NotificationManager.get().isNotified(ev.title));
        cb.addActionListener(ae -> {
            NotificationManager.get().setNotified(ev.title, cb.isSelected());
            updateBadge();
        });
        notificationMap.put(ev, cb);

        JLabel loc = new JLabel(loadScaled("ubi1.png", 24, 24));
        loc.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loc.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                showMapDialog(ev.place);
            }
        });
        JPanel bot = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bot.setOpaque(false);
        bot.add(loc);
        bot.add(cb);
        card.add(bot, BorderLayout.SOUTH);

        return card;
    }

    private void updateBadge() {
        long cnt = notificationMap.values().stream().filter(JCheckBox::isSelected).count();
        notiBtn.setText("\uD83D\uDD14 " + cnt);
    }

    private void showDetailDialog(Event ev) {
        JDialog dlg = new JDialog(this, ev.title, true);
        dlg.setLayout(new BorderLayout());
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        p.add(new JLabel("Descripción: " + ev.description));
        p.add(Box.createVerticalStrut(8));
        p.add(new JLabel("Fecha:       " + ev.date));
        p.add(Box.createVerticalStrut(8));
        p.add(new JLabel("Hora:        " + ev.time));
        p.add(Box.createVerticalStrut(8));
        p.add(new JLabel("Lugar:       " + ev.place));
        p.add(Box.createVerticalStrut(8));
        p.add(new JLabel("Categoría:   " + ev.category));
        p.add(Box.createVerticalStrut(8));
        p.add(new JLabel("Duración:    " + ev.duration + " h"));

        JButton close = new JButton("Cerrar");
        close.addActionListener(e -> dlg.dispose());
        JPanel btn = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btn.add(close);

        dlg.add(p, BorderLayout.CENTER);
        dlg.add(btn, BorderLayout.SOUTH);
        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    private void showNotifications() {
        if (notificationMap.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay eventos.", "Notificaciones", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        LocalDate today = LocalDate.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es", "ES"));
        StringBuilder sb = new StringBuilder("<html>");
        boolean any = false;
        for (Map.Entry<Event, JCheckBox> en : notificationMap.entrySet()) {
            if (en.getValue().isSelected()) {
                any = true;
                Event ev = en.getKey();
                long days;
                try {
                    days = ChronoUnit.DAYS.between(today, LocalDate.parse(ev.date, fmt));
                } catch (Exception ex) {
                    days = Long.MIN_VALUE;
                }
                sb.append(ev.title).append(" - ");
                if (days < 0) sb.append("Ya pasó");
                else if (days == 0) sb.append("Hoy");
                else sb.append("Faltan ").append(days).append(" días");
                sb.append("<br>");
            }
        }
        if (!any) sb.append("No seleccionaste ningún evento.");
        sb.append("</html>");
        JOptionPane.showMessageDialog(this, sb.toString(), "Mis Notificaciones", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showSimulatorDialog() {
        JDialog dlg = new JDialog(this, "Simulador de Horas", true);
        dlg.setLayout(new BorderLayout());
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        for (Event ev : allEvents) {
            p.add(new JCheckBox(ev.title + " (" + ev.duration + " h)"));
        }
        JScrollPane sp = new JScrollPane(p);
        sp.setPreferredSize(new Dimension(400, 300));

        JLabel result = new JLabel("Horas base: " + CURRENT_HOURS + " / " + TOTAL_HOURS);
        JButton calc = new JButton("Calcular");
        calc.addActionListener(e -> {
            int sum = 0;
            for (Component c : p.getComponents()) {
                if (c instanceof JCheckBox && ((JCheckBox) c).isSelected()) {
                    String t = ((JCheckBox) c).getText().replaceAll(".*\\((\\d+) h\\).*", "$1");
                    sum += Integer.parseInt(t);
                }
            }
            int total = Math.min(CURRENT_HOURS + sum, TOTAL_HOURS);
            int faltan = TOTAL_HOURS - total;
            int pct = (int) Math.round(100.0 * total / TOTAL_HOURS);
            result.setText("<html>Horas base: " + CURRENT_HOURS + "<br>Sumadas: " + sum +
                "<br>Total: " + total + " h (" + pct + "%)<br>Faltan: " + faltan + " h</html>");
            dlg.pack();
        });

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btns.add(calc);
        JButton close = new JButton("Cerrar");
        close.addActionListener(e -> dlg.dispose());
        btns.add(close);

        dlg.add(sp, BorderLayout.CENTER);
        dlg.add(result, BorderLayout.NORTH);
        dlg.add(btns, BorderLayout.SOUTH);
        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    private void showMapDialog(String place) {
        JDialog dlg = new JDialog(this, "Mapa UNAB", true);
        dlg.setSize(600, 600);
        dlg.setLocationRelativeTo(this);
        dlg.add(new MapPanel(place));
        dlg.setVisible(true);
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245, 245, 245));
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        left.setOpaque(false);
        left.add(new JLabel(loadScaled("logo_inferior.png", 60, 60)));
        left.add(new JLabel(loadScaled("texto_largo.png", 260, 60)));
        footer.add(left, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1, 2, 100, 0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes", "https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales", "https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB", "https://repository.unab.edu.co"},
            {"Sistema de bibliotecas", "https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube", "https://www.youtube.com/@unabeduco"},
            {"Linkedin", "https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter", "https://twitter.com/unab_online"},
            {"Instagram", "https://www.instagram.com/unab_online/"},
            {"Facebook", "https://www.facebook.com/unab.online/"}
        }));
        footer.add(cols, BorderLayout.CENTER);
        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans", Font.BOLD, 12));
        t.setForeground(new Color(164, 164, 164));
        col.add(t);
        col.add(Box.createVerticalStrut(8));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans", Font.PLAIN, 12));
            l.setForeground(new Color(164, 164, 164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            String url = d[1];
            l.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { openURL(url); }
                public void mouseEntered(MouseEvent e) { l.setForeground(new Color(120,120,120)); }
                public void mouseExited(MouseEvent e) { l.setForeground(new Color(164,164,164)); }
            });
            col.add(l);
            col.add(Box.createVerticalStrut(4));
        }
        return col;
    }

    private void toggleDarkMode() {
        boolean dark = !ThemeManager.isDarkMode();
        ThemeManager.setDarkMode(dark);

        Color bg = dark ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = dark ? Color.WHITE        : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);
    }

    private void applyTheme(Component comp, Color bg, Color fg) {
        boolean dark = ThemeManager.isDarkMode();
        if (comp instanceof JPanel) {
            comp.setBackground(bg);
            for (Component child : ((JPanel) comp).getComponents()) {
                applyTheme(child, bg, fg);
            }
        } else if (comp instanceof JScrollPane) {
            JScrollPane sp = (JScrollPane) comp;
            sp.getViewport().setBackground(bg);
            applyTheme(sp.getViewport().getView(), bg, fg);
        } else if (comp instanceof JButton) {
            JButton b = (JButton) comp;
            b.setBackground(dark ? new Color(70,70,70) : new Color(240,240,240));
            b.setForeground(fg);
        } else if (comp instanceof JLabel) {
            ((JLabel) comp).setForeground(fg);
        }
    }

    private ImageIcon loadScaled(String name, int w, int h) {
        try (InputStream is = getClass().getResourceAsStream(IMG_ROOT + name)) {
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH));
        } catch (Exception e) {
            return new ImageIcon(new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB));
        }
    }

    private void openURL(String url) {
        try { Desktop.getDesktop().browse(new URI(url)); }
        catch (Exception ignored) {}
    }

    private class MapPanel extends JPanel {
        private BufferedImage mapImg;
        private Point marker;
        MapPanel(String place) {
            try { mapImg = ImageIO.read(getClass().getResource(IMG_ROOT + "mapa.jpg")); }
            catch (IOException e) { mapImg = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB); }
            switch (place) {
                case "Auditorio Menor": marker = new Point(120,200); break;
                case "Galería de Arte UNAB": marker = new Point(300,250); break;
                default: marker = new Point(50,50); break;
            }
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(mapImg,0,0,getWidth(),getHeight(),null);
            g.setColor(Color.RED);
            int r=10;
            int mx = marker.x*getWidth()/mapImg.getWidth();
            int my = marker.y*getHeight()/mapImg.getHeight();
            g.fillOval(mx-r/2, my-r/2, r, r);
        }
    }

    private static class Event {
        String title, date, time, place, description, category;
        int duration;
        Event(String t, String d1, String t1, String p, String desc, String cat, int dur) {
            title=t; date=d1; time=t1; place=p; description=desc; category=cat; duration=dur;
        }
    }

    private static class TempEvent {
        String titulo, descripcion, fecha, hora, lugar, categoria;
        int duracion;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EventosFrame::new);
    }
}
