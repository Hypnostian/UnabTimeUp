package proyectoestructura;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public class NotificationManager {
    private static NotificationManager instance;
    private final Set<String> notifiedTitles;

    private NotificationManager() {
        this.notifiedTitles = new HashSet<>();
    }

    /** Devuelve la instancia única. */
    public static synchronized NotificationManager get() {
        if (instance == null) {
            instance = new NotificationManager();
        }
        return instance;
    }

    /**
     * Marca o desmarca un título de evento.
     * @param title El título del evento
     * @param notified true para añadir; false para quitar
     */
    public void setNotified(String title, boolean notified) {
        if (notified) {
            notifiedTitles.add(title);
        } else {
            notifiedTitles.remove(title);
        }
    }

    /** ¿Está marcado el evento con este título? */
    public boolean isNotified(String title) {
        return notifiedTitles.contains(title);
    }

    /** Devuelve los títulos actualmente marcados. */
    public Set<String> getNotifiedTitles() {
        return Collections.unmodifiableSet(notifiedTitles);
    }

    /** Cantidad de eventos notificados. */
    public int count() {
        return notifiedTitles.size();
    }

    /**
     * Borra todas las notificaciones.
     * (Opcional, por si quieres un "Limpiar notificaciones" en algún menú.)
     */
    public void clear() {
        notifiedTitles.clear();
    }
}
