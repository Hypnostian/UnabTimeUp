package proyectoestructura;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import proyectoestructura.ThemeManager;
import proyectoestructura.NotificationManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class HistorialFrame extends JFrame {
    private static final String IMG_ROOT = "/images/";
    private boolean darkMode;
    private JButton notiBtn;
    private JPanel headerPanel, footerPanel;
    private JScrollPane centerScroll;
    private List<HistoryEvent> historyEvents = new ArrayList<>();
    private Map<String,String> titleToDate = new HashMap<>();

    public HistorialFrame() {
        super("Historial – Unab TimeUp");
        setMinimumSize(new Dimension(1024, 640));
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        loadEventDates();
        loadHistoryEvents();

        headerPanel = buildHeader();
        add(headerPanel, BorderLayout.NORTH);

        centerScroll = buildCenter();
        add(centerScroll, BorderLayout.CENTER);

        footerPanel = buildFooter();
        add(footerPanel, BorderLayout.SOUTH);

        // tema y notificaciones
        darkMode = ThemeManager.isDarkMode();
        updateBadge();
        Color bg = darkMode ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = darkMode ? Color.WHITE : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadEventDates() {
        try (InputStream is = getClass().getResourceAsStream("/resources/eventos.json");
             Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            List<TempEvent> tmp = new Gson().fromJson(r, new TypeToken<List<TempEvent>>(){}.getType());
            for (TempEvent e : tmp) titleToDate.put(e.titulo, e.fecha);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadHistoryEvents() {
        try (InputStream is = getClass().getResourceAsStream("/resources/Erealizados.json");
             Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            historyEvents = new Gson().fromJson(r, new TypeToken<List<HistoryEvent>>(){}.getType());
        } catch (Exception ex) {
            ex.printStackTrace();
            historyEvents = new ArrayList<>();
        }
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245,245,245));

        // logos izquierda
        JPanel west = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        west.setOpaque(false);
        west.add(new JLabel(loadScaled("logo_inferior.png",100,100)));
        west.add(new JLabel(loadScaled("logito_1.png",200,90)));
        header.add(west, BorderLayout.WEST);

        // menú centro
        String[] names = {"Inicio","Eventos","Historial","Mi agenda","Soportes"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER,20,15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif",Font.BOLD,14));
            b.setPreferredSize(new Dimension(160,40));
            b.setBackground(new Color(240,240,240));
            b.setBorder(new LineBorder(new Color(200,200,200),1,true));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setFocusPainted(false);
            switch(n) {
                case "Inicio":    b.addActionListener(e->{ new InicioFrame().setVisible(true); dispose(); }); break;
                case "Eventos":   b.addActionListener(e->{ new EventosFrame().setVisible(true); dispose(); }); break;
                case "Historial": b.setEnabled(false); break;
                case "Mi agenda": b.addActionListener(e->{ new MiAgendaFrame().setVisible(true); dispose(); }); break;
                case "Soportes":  b.addActionListener(e->{ new SoportesFrame().setVisible(true); dispose(); }); break;
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        // iconos derecha
        JPanel east = new JPanel(new FlowLayout(FlowLayout.RIGHT,20,12));
        east.setOpaque(false);

        notiBtn = new JButton("\uD83D\uDD14 0");
        notiBtn.setFont(new Font("SansSerif",Font.BOLD,12));
        notiBtn.setContentAreaFilled(false);
        notiBtn.setBorder(null);
        notiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notiBtn.addActionListener(e-> showNotifications());
        east.add(notiBtn);

        JButton profileBtn = new JButton(loadScaled("perfil.png",30,30));
        profileBtn.setContentAreaFilled(false);
        profileBtn.setBorder(null);
        profileBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        profileBtn.addActionListener(e->{ new PerfilFrame().setVisible(true); dispose(); });
        east.add(profileBtn);

        JButton darkBtn = new JButton(loadScaled("modo_oscuro.png",30,30));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e-> toggleDarkMode());
        east.add(darkBtn);

        header.add(east, BorderLayout.EAST);
        return header;
    }

    private JScrollPane buildCenter() {
        // separa calificados y sin calificar, mantiene orden histórico
        List<HistoryEvent> rated = historyEvents.stream()
            .filter(h -> h.calificacion > 0)
            .collect(Collectors.toList());
        List<HistoryEvent> unrated = historyEvents.stream()
            .filter(h -> h.calificacion == 0)
            .collect(Collectors.toList());

        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container,BoxLayout.X_AXIS));
        container.setBackground(darkMode?new Color(30,30,30):Color.WHITE);

        // columna calificados
        JPanel colRated = new JPanel();
        colRated.setLayout(new BoxLayout(colRated,BoxLayout.Y_AXIS));
        colRated.setOpaque(true);
        colRated.setBackground(darkMode?new Color(30,30,30):Color.WHITE);
        colRated.setBorder(new EmptyBorder(10,10,10,5));
        for (HistoryEvent h : rated) {
            colRated.add(createRatedCard(h));
            colRated.add(Box.createVerticalStrut(10));
        }

        // columna sin calificar
        JPanel colUnrated = new JPanel();
        colUnrated.setLayout(new BoxLayout(colUnrated,BoxLayout.Y_AXIS));
        colUnrated.setOpaque(true);
        colUnrated.setBackground(darkMode?new Color(30,30,30):Color.WHITE);
        colUnrated.setBorder(new EmptyBorder(10,5,10,10));
        for (HistoryEvent h : unrated) {
            colUnrated.add(createUnratedCard(h));
            colUnrated.add(Box.createVerticalStrut(10));
        }

        container.add(Box.createHorizontalStrut(10));
        container.add(colRated);
        container.add(Box.createHorizontalStrut(10));
        container.add(colUnrated);
        container.add(Box.createHorizontalStrut(10));

        centerScroll = new JScrollPane(container,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        centerScroll.setBorder(null);
        centerScroll.getViewport().setBackground(darkMode?new Color(30,30,30):Color.WHITE);
        return centerScroll;
    }

    private JPanel createRatedCard(HistoryEvent h) {
        JPanel card = new JPanel(new BorderLayout(10,10));
        card.setOpaque(true);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200,200,200),1,true),
            new EmptyBorder(10,10,10,10)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE,120));
        Color fg = darkMode?Color.WHITE:Color.DARK_GRAY;

        JLabel titulo = new JLabel(h.titulo);
        titulo.setFont(new Font("SansSerif",Font.BOLD,16));
        titulo.setForeground(fg);

        JLabel horas = new JLabel("Horas acumuladas: "+h.horasAcumuladas+"/"+h.horasTotales);
        horas.setForeground(fg);

        JLabel estrellas = new JLabel("★".repeat(h.calificacion));
        estrellas.setForeground(new Color(246,156,0));

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS));
        info.add(titulo);
        info.add(Box.createVerticalStrut(5));
        info.add(horas);
        info.add(Box.createVerticalStrut(5));
        info.add(estrellas);
        if (!h.comentario.isBlank()) {
            JLabel coment = new JLabel("<html><i>"+h.comentario+"</i></html>");
            coment.setForeground(fg);
            info.add(Box.createVerticalStrut(5));
            info.add(coment);
        }

        card.add(info, BorderLayout.CENTER);
        return card;
    }

    private JPanel createUnratedCard(HistoryEvent h) {
        JPanel card = new JPanel(new BorderLayout(10,10));
        card.setOpaque(true);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200,200,200),1,true),
            new EmptyBorder(10,10,10,10)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE,120));
        Color fg = darkMode?Color.WHITE:Color.DARK_GRAY;

        JLabel titulo = new JLabel(h.titulo);
        titulo.setFont(new Font("SansSerif",Font.BOLD,16));
        titulo.setForeground(fg);

        JLabel horas = new JLabel("Horas acumuladas: "+h.horasAcumuladas+"/"+h.horasTotales);
        horas.setForeground(fg);

        JButton btn = new JButton("Calificar");
        btn.setBackground(new Color(246,156,0));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.addActionListener(e -> {
            JDialog d = new JDialog(this, "Reseñar: "+h.titulo, true);
            d.setSize(400,300);
            d.setLayout(new BorderLayout());

            JPanel p = new JPanel();
            p.setBorder(new EmptyBorder(10,10,10,10));
            p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
            p.add(new JLabel("Calificación (1-5):"));
            JSpinner spn = new JSpinner(new SpinnerNumberModel(5,1,5,1));
            spn.setMaximumSize(new Dimension(60, spn.getPreferredSize().height));
            p.add(spn);
            p.add(Box.createVerticalStrut(10));
            p.add(new JLabel("Comentario:"));
            JTextArea ta = new JTextArea();
            ta.setLineWrap(true);
            ta.setWrapStyleWord(true);
            JScrollPane sp = new JScrollPane(ta);
            sp.setPreferredSize(new Dimension(360,120));
            p.add(sp);

            JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            JButton send = new JButton("Enviar");
            send.addActionListener(a -> {
                h.calificacion = (Integer) spn.getValue();
                h.comentario = ta.getText().trim();
                d.dispose();
                refreshCenter();
            });
            btns.add(send);
            JButton cancel = new JButton("Cancelar");
            cancel.addActionListener(a -> d.dispose());
            btns.add(cancel);

            d.add(p, BorderLayout.CENTER);
            d.add(btns, BorderLayout.SOUTH);
            d.setLocationRelativeTo(this);
            d.setVisible(true);
        });

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS));
        info.add(titulo);
        info.add(Box.createVerticalStrut(5));
        info.add(horas);
        info.add(Box.createVerticalStrut(5));
        info.add(btn);

        card.add(info, BorderLayout.CENTER);
        return card;
    }

    private void refreshCenter() {
        remove(centerScroll);
        centerScroll = buildCenter();
        add(centerScroll, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245,245,245));

        JPanel L = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        L.setOpaque(false);
        L.add(new JLabel(loadScaled("logo_inferior.png",60,60)));
        L.add(new JLabel(loadScaled("texto_largo.png",260,60)));
        footer.add(L, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1,2,100,0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes","https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales","https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB","https://repository.unab.edu.co"},
            {"Bibliotecas UNAB","https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube","https://www.youtube.com/@unabeduco"},
            {"LinkedIn","https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter","https://twitter.com/unab_online"},
            {"Instagram","https://www.instagram.com/unab_online/"},
            {"Facebook","https://www.facebook.com/unab.online/"}
        }));
        footer.add(cols, BorderLayout.CENTER);
        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col,BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans",Font.BOLD,12));
        t.setForeground(new Color(164,164,164));
        col.add(t); col.add(Box.createVerticalStrut(8));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans",Font.PLAIN,12));
            l.setForeground(new Color(164,164,164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            l.addMouseListener(new MouseAdapter(){
                public void mouseClicked(MouseEvent e){ openURL(d[1]); }
                public void mouseEntered(MouseEvent e){ l.setForeground(new Color(120,120,120)); }
                public void mouseExited(MouseEvent e){ l.setForeground(new Color(164,164,164)); }
            });
            col.add(l); col.add(Box.createVerticalStrut(4));
        }
        return col;
    }

    private void toggleDarkMode() {
        darkMode = !ThemeManager.isDarkMode();
        ThemeManager.setDarkMode(darkMode);
        Color bg = darkMode?new Color(45,45,45):new Color(245,245,245);
        Color fg = darkMode?Color.WHITE:Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);
    }

    private void applyTheme(Component c, Color bg, Color fg) {
        if (c instanceof JPanel) {
            c.setBackground(bg);
            for (Component ch : ((JPanel)c).getComponents()) applyTheme(ch,bg,fg);
        } else if (c instanceof JLabel) {
            ((JLabel)c).setForeground(fg);
        } else if (c instanceof JButton) {
            ((JButton)c).setBackground(darkMode?new Color(70,70,70):new Color(240,240,240));
            ((JButton)c).setForeground(fg);
        } else if (c instanceof JScrollPane) {
            JScrollPane sp = (JScrollPane)c;
            sp.getViewport().setBackground(bg);
            applyTheme(sp.getViewport().getView(), bg, fg);
        }
    }

    private void updateBadge() {
        notiBtn.setText("\uD83D\uDD14 " + NotificationManager.get().count());
    }

    private void showNotifications() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es","ES"));
        StringBuilder sb = new StringBuilder("<html>");
        boolean any = false;
        for (String t : NotificationManager.get().getNotifiedTitles()) {
            any = true;
            long days;
            try {
                days = ChronoUnit.DAYS.between(today, LocalDate.parse(titleToDate.get(t), fmt));
            } catch (Exception ex) {
                days = Long.MIN_VALUE;
            }
            sb.append(t).append(" – ");
            if (days<0)      sb.append("Ya pasó");
            else if (days==0)sb.append("Hoy");
            else             sb.append("Faltan ").append(days).append(" días");
            sb.append("<br>");
        }
        if (!any) sb.append("No hay notificaciones.");
        sb.append("</html>");
        JOptionPane.showMessageDialog(this, sb.toString(), "Notificaciones", JOptionPane.INFORMATION_MESSAGE);
    }

    private static ImageIcon loadScaled(String name,int w,int h) {
        try(InputStream is = HistorialFrame.class.getResourceAsStream(IMG_ROOT + name)) {
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w,h,Image.SCALE_SMOOTH));
        } catch(Exception e) {
            return new ImageIcon(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));
        }
    }

    private void openURL(String u) {
        try { Desktop.getDesktop().browse(new URI(u)); }
        catch(Exception ignored) {}
    }

    // inner para cargar fechas de notificaciones
    private static class TempEvent {
        String titulo, descripcion, fecha, hora, lugar, categoria;
        int duracion;
    }

    // modelo historial
    private static class HistoryEvent {
        String titulo, descripcion, fecha;
        int horasAcumuladas, horasTotales, calificacion;
        String comentario = "";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HistorialFrame::new);
    }
}
