package proyectoestructura;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.awt.Desktop;
import java.util.List;
import java.util.ArrayList;

public class MainApp extends JFrame {

    private static final String IMG_ROOT = "/images/";
    private boolean darkMode = false;

    public MainApp() {
        setTitle("Unab TimeUp");
        setMinimumSize(new Dimension(1024, 640));
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        // Aplicar tema inicial
        Color bg = darkMode ? new Color(45, 45, 45) : new Color(245, 245, 245);
        Color fg = darkMode ? Color.WHITE : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    /* ---------------- Center ---------------- */
    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Color.WHITE);

        // Construir lista de slides
        List<String[]> slides = new ArrayList<>();
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "Banner.png"});
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "banner1.png"});
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "banner2.jpg"});
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "banner3.jpg"}); 
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "banner4.jpg"});   
        slides.add(new String[]{IMG_ROOT + "texto_central.png", IMG_ROOT + "banner5.jpg"});         
        // Agregar más slides aquí cuando estén disponibles

        // Carousel con texto 600x350 y banner 500x350
        CarouselPanel carousel = new CarouselPanel(slides, 600, 350, 500, 350);
        center.add(carousel, BorderLayout.CENTER);
        return center;
    }

    /* ---------------- Header ---------------- */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245, 245, 245));

        JLabel logo = new JLabel(loadScaled(IMG_ROOT + "logo_inferior.png", 100, 100));
        JLabel logito = new JLabel(loadScaled(IMG_ROOT + "logito_1.png", 200, 90));
        JPanel logoBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        logoBox.setOpaque(false);
        logoBox.add(logo);
        logoBox.add(logito);
        header.add(logoBox, BorderLayout.WEST);

        String[] names = {"¿Qué es TimeUp?", "Canales", "Bienestar Unab", "Inicio sesión"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif", Font.BOLD, 14));
            b.setBackground(new Color(240, 240, 240));
            b.setPreferredSize(new Dimension(160, 40));
            b.setBorder(new LineBorder(new Color(200, 200, 200), 1, true));
            b.setFocusPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            if (n.equals("Inicio sesión")) {
                b.addActionListener(e -> {
                    new LoginFrame().setVisible(true);
                    dispose();
                });
            } else if (n.equals("¿Qué es TimeUp?")) {
                b.addActionListener(e -> new QueEsTimeUpFrame().setVisible(true));
            } else if (n.equals("Canales")) {
                b.setText("Canales \u25BE");
                JPopupMenu canalesMenu = new JPopupMenu();
                JMenuItem itemTema = new JMenuItem("TEMA");
                itemTema.addActionListener(e -> open("https://tema.unab.edu.co/"));
                canalesMenu.add(itemTema);
                JMenuItem itemCosmos = new JMenuItem("COSMOS");
                itemCosmos.addActionListener(e -> open("https://cosmos.unab.edu.co/"));
                canalesMenu.add(itemCosmos);
                JMenuItem itemUnab = new JMenuItem("UNAB");
                itemUnab.addActionListener(e -> open("https://unab.edu.co/"));
                canalesMenu.add(itemUnab);
                JMenuItem itemBiblioteca = new JMenuItem("Biblioteca UNAB");
                itemBiblioteca.addActionListener(e -> open("https://catalogo.unab.edu.co/"));
                canalesMenu.add(itemBiblioteca);
                JMenuItem itemMiPortal = new JMenuItem("Mi Portal U");
                itemMiPortal.addActionListener(e -> open("https://miportalu.unab.edu.co/"));
                canalesMenu.add(itemMiPortal);
                b.addActionListener(e -> {
                    Dimension pd = canalesMenu.getPreferredSize();
                    canalesMenu.setPopupSize(b.getWidth(), pd.height);
                    canalesMenu.show(b, 0, b.getHeight());
                });
            } else if (n.equals("Bienestar Unab")) {
                b.addActionListener(e -> open("https://www.instagram.com/bienestar_unab/"));
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        JButton darkBtn = new JButton(loadScaled(IMG_ROOT + "modo_oscuro.png", 30, 30));
        darkBtn.setPreferredSize(new Dimension(36, 36));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e -> toggleDarkMode());
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
        right.setOpaque(false);
        right.add(darkBtn);
        header.add(right, BorderLayout.EAST);

        return header;
    }

    /* ---------------- Footer ---------------- */
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245, 245, 245));

        JLabel logoInf = new JLabel(loadScaled(IMG_ROOT + "logo_inferior.png", 60, 60));
        JLabel legalImg = new JLabel(loadScaled(IMG_ROOT + "texto_largo.png", 260, 60));
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        left.setOpaque(false);
        left.add(logoInf);
        left.add(legalImg);
        footer.add(left, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1, 2, 100, 0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes", "https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales", "https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB", "https://repository.unab.edu.co"},
            {"Sistema de bibliotecas UNAB", "https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube", "https://www.youtube.com/@unabeduco"},
            {"Linkedin", "https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter", "https://x.com/unab_online"},
            {"Instagram", "https://www.instagram.com/unab_online/?hl=es"},
            {"Facebook", "https://www.facebook.com/unab.online/?locale=es_LA"}
        }));
        footer.add(cols, BorderLayout.CENTER);

        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans", Font.BOLD, 12));
        t.setForeground(new Color(164, 164, 164));
        col.add(t);
        col.add(Box.createVerticalStrut(8));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans", Font.PLAIN, 12));
            l.setForeground(new Color(164, 164, 164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            String url = d[1];
            l.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    open(url);
                }
                public void mouseEntered(MouseEvent e) {
                    l.setForeground(new Color(120,120,120));
                }
                public void mouseExited(MouseEvent e) {
                    l.setForeground(new Color(164,164,164));
                }
            });
            col.add(l);
        }
        return col;
    }

    /* ---------------- Dark Mode ---------------- */
    private void toggleDarkMode() {
        darkMode = !darkMode;
        Color bg = darkMode ? new Color(45, 45, 45) : new Color(245, 245, 245);
        Color fg = darkMode ? Color.WHITE : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);
    }

    private void applyTheme(Component comp, Color bg, Color fg) {
        if (comp instanceof JPanel) {
            comp.setBackground(bg);
            for (Component child : ((JPanel) comp).getComponents()) {
                applyTheme(child, bg, fg);
            }
        } else if (comp instanceof JLabel) {
            ((JLabel) comp).setForeground(fg);
        } else if (comp instanceof JButton) {
            ((JButton) comp).setBackground(darkMode ? new Color(70, 70, 70) : new Color(240, 240, 240));
            ((JButton) comp).setForeground(fg);
        }
    }

    /* ---------------- CarouselPanel ---------------- */
    private class CarouselPanel extends JPanel {
        private final CardLayout cl = new CardLayout();
        private final Timer autoTimer;
        private final List<String[]> slides;
        private JPanel cards;
        private int current = 0;
        private final List<JLabel> dots = new ArrayList<>();

        CarouselPanel(List<String[]> slides, int textW, int textH, int bannerW, int bannerH) {
            this.slides = slides;
            setLayout(new BorderLayout());
            cards = new JPanel(cl);
            cards.setOpaque(false);
            for (int i = 0; i < slides.size(); i++) {
                String[] pair = slides.get(i);
                JPanel slide = new JPanel(new BorderLayout());
                slide.setOpaque(false);
                JLabel txt = new JLabel(loadScaled(pair[0], textW, textH));
                txt.setHorizontalAlignment(SwingConstants.CENTER);
                slide.add(txt, BorderLayout.WEST);
                JLabel ban = new JLabel(loadScaled(pair[1], bannerW, bannerH));
                ban.setHorizontalAlignment(SwingConstants.CENTER);
                slide.add(ban, BorderLayout.CENTER);
                cards.add(slide, String.valueOf(i));
            }
            add(cards, BorderLayout.CENTER);

            JButton prev = new JButton(loadScaled(IMG_ROOT + "flecha_izq.png", 40, 40));
            JButton next = new JButton(loadScaled(IMG_ROOT + "flecha_dere.png", 40, 40));
            for (JButton btn : new JButton[]{prev, next}) {
                btn.setContentAreaFilled(false);
                btn.setBorder(null);
                btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            prev.addActionListener(e -> { showSlide((current - 1 + slides.size()) % slides.size()); resetTimer(); });
            next.addActionListener(e -> { showSlide((current + 1) % slides.size()); resetTimer(); });
            add(prev, BorderLayout.WEST);
            add(next, BorderLayout.EAST);

            JPanel dotsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
            dotsPanel.setOpaque(false);
            for (int i = 0; i < slides.size(); i++) {
                JLabel dot = new JLabel("○");
                dot.setFont(new Font("SansSerif", Font.PLAIN, 18));
                dots.add(dot);
                dotsPanel.add(dot);
            }
            add(dotsPanel, BorderLayout.SOUTH);

            autoTimer = new Timer(10000, e -> showSlide((current + 1) % slides.size()));
            autoTimer.start();
            showSlide(0);
        }

        private void showSlide(int index) {
            current = index;
            cl.show(cards, String.valueOf(index));
            for (int i = 0; i < dots.size(); i++) {
                dots.get(i).setText(i == current ? "●" : "○");
            }
        }

        private void resetTimer() {
            if (autoTimer != null) autoTimer.restart();
        }
    }

    /* ---------------- Utilities ---------------- */
    private static ImageIcon loadScaled(String path, int w, int h) {
        try (InputStream is = MainApp.class.getResourceAsStream(path)) {
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH));
        } catch (IOException e) {
            return new ImageIcon(new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB));
        }
    }

    private void open(String url) {
        try { Desktop.getDesktop().browse(new URI(url)); }
        catch (Exception ignored) {}
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainApp::new);
    }
}
