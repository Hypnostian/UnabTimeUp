package proyectoestructura;

public class ThemeManager {
    private static boolean darkMode = false;
    private ThemeManager() {}

    /** Devuelve el estado actual. */
    public static boolean isDarkMode() {
        return darkMode;
    }

    /** Cambia el estado y lo guarda. */
    public static void setDarkMode(boolean dm) {
        darkMode = dm;
    }
}
