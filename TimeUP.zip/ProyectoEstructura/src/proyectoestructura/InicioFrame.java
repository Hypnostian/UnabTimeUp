package proyectoestructura;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import proyectoestructura.ThemeManager;

/** Asegúrate de tener:
 *  - /images/eventos.json junto al resto de recursos
 *  - clase NotificationManager que guarde títulos marcados
 *  - clase ThemeManager para persistir modo oscuro
 *  - inner static class TempEvent aquí igual a la de EventosFrame
 *  - inner static class Event aquí igual a la de EventosFrame
 */
public class InicioFrame extends JFrame {
    private static final String     IMG_ROOT    = "/images/";
    private static final String     JSON_PATH   = "/resources/eventos.json";
    private static final Color      ORANGE      = new Color(0xF6,0x9C,0x00);

    private boolean darkMode = false;
    private JButton notiBtn;
    private List<Event> allEvents;

    public InicioFrame() {
        super("Inicio - Unab TimeUp");
        setMinimumSize(new Dimension(1024,640));
        setSize(1280,720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 1) cargo la lista de eventos para poder calcular días
        try {
            loadEvents();
        } catch(Exception ex) {
            ex.printStackTrace();
            // fallback mínimo
            allEvents = Collections.emptyList();
        }

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        // recarga el contador al iniciar
        updateBadge();
        // aplica tema persistente
        darkMode = ThemeManager.isDarkMode();
        Color bg = darkMode ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = darkMode ? Color.WHITE : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadEvents() throws IOException {
        InputStream is = getClass().getResourceAsStream(JSON_PATH);
        if (is == null) throw new FileNotFoundException(JSON_PATH);
        try (Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            Gson gson = new Gson();
            java.lang.reflect.Type listType = new TypeToken<List<TempEvent>>(){}.getType();
            List<TempEvent> temp = gson.fromJson(r, listType);
            allEvents = temp.stream()
                .map(te -> new Event(
                    te.titulo,
                    te.fecha,
                    te.hora,
                    te.lugar,
                    te.descripcion,
                    te.categoria,
                    te.duracion
                ))
                .collect(Collectors.toList());
        }
    }

    /* ---------------- Header ---------------- */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245,245,245));

        // Izquierda: logos
        JPanel west = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        west.setOpaque(false);
        west.add(new JLabel(loadScaled("logo_inferior.png",100,100)));
        west.add(new JLabel(loadScaled("logito_1.png",200,90)));
        header.add(west, BorderLayout.WEST);

        // Centro: menú
        String[] names = {"Inicio","Eventos","Historial","Mi agenda","Soportes"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER,20,15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif",Font.BOLD,14));
            b.setPreferredSize(new Dimension(160,40));
            b.setBackground(new Color(240,240,240));
            b.setBorder(new LineBorder(new Color(200,200,200),1,true));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setFocusPainted(false);
            switch(n) {
                case "Inicio":    b.setEnabled(false); break;
                case "Eventos":   b.addActionListener(e->{ new EventosFrame().setVisible(true); dispose(); }); break;
                case "Historial": b.addActionListener(e->{ new HistorialFrame().setVisible(true); dispose(); }); break;
                case "Mi agenda": b.addActionListener(e->{ new MiAgendaFrame().setVisible(true); dispose(); }); break;
                case "Soportes":  b.addActionListener(e->{ new SoportesFrame().setVisible(true); dispose(); }); break;
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        // Derecha: campana, perfil, modo oscuro
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,20,12));
        right.setOpaque(false);

        // campana
        notiBtn = new JButton("\uD83D\uDD14 0");
        notiBtn.setFont(new Font("SansSerif",Font.BOLD,12));
        notiBtn.setContentAreaFilled(false);
        notiBtn.setBorder(null);
        notiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notiBtn.addActionListener(e-> showNotifications());
        right.add(notiBtn);

        // perfil
        JButton profileBtn = new JButton(loadScaled("perfil.png",30,30));
        profileBtn.setContentAreaFilled(false);
        profileBtn.setBorder(null);
        profileBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        profileBtn.addActionListener(e->{ new PerfilFrame().setVisible(true); dispose(); });
        right.add(profileBtn);

        // modo oscuro
        JButton darkBtn = new JButton(loadScaled("modo_oscuro.png",30,30));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e-> toggleDarkMode());
        right.add(darkBtn);

        header.add(right, BorderLayout.EAST);
        return header;
    }

    /* ---------------- Center ---------------- */
    private JPanel buildCenter() {
        BufferedImage img = loadBuffered("ilus_inicio.png");
        return new ImagePanel(img);
    }

    /* ---------------- Footer ---------------- */
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245,245,245));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        left.setOpaque(false);
        left.add(new JLabel(loadScaled("logo_inferior.png",60,60)));
        left.add(new JLabel(loadScaled("texto_largo.png",260,60)));
        footer.add(left, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1,2,100,0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes","https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales","https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB","https://repository.unab.edu.co"},
            {"Sistema de bibliotecas","https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube","https://www.youtube.com/@unabeduco"},
            {"Linkedin","https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter","https://twitter.com/unab_online"},
            {"Instagram","https://www.instagram.com/unab_online/"},
            {"Facebook","https://www.facebook.com/unab.online/"}
        }));
        footer.add(cols, BorderLayout.CENTER);
        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col,BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans",Font.BOLD,12));
        t.setForeground(new Color(164,164,164));
        col.add(t);
        col.add(Box.createVerticalStrut(8));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans",Font.PLAIN,12));
            l.setForeground(new Color(164,164,164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            String url = d[1];
            l.addMouseListener(new MouseAdapter(){
                @Override public void mouseClicked(MouseEvent e){ openURL(url); }
                @Override public void mouseEntered(MouseEvent e){ l.setForeground(new Color(120,120,120)); }
                @Override public void mouseExited(MouseEvent e){ l.setForeground(new Color(164,164,164)); }
            });
            col.add(l);
            col.add(Box.createVerticalStrut(4));
        }
        return col;
    }

    /* ---------------- Dark Mode ---------------- */
    private void toggleDarkMode() {
        darkMode = !ThemeManager.isDarkMode();
        ThemeManager.setDarkMode(darkMode);
        Color bg = darkMode ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = darkMode ? Color.WHITE : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);
    }
    private void applyTheme(Component comp, Color bg, Color fg) {
        if (comp instanceof JPanel) {
            comp.setBackground(bg);
            for (Component c:((JPanel)comp).getComponents()) applyTheme(c,bg,fg);
        } else if (comp instanceof JLabel) {
            ((JLabel)comp).setForeground(fg);
        } else if (comp instanceof JButton) {
            ((JButton)comp).setBackground(darkMode?new Color(70,70,70):new Color(240,240,240));
            ((JButton)comp).setForeground(fg);
        } else if (comp instanceof JScrollPane) {
            JScrollPane sp = (JScrollPane) comp;
            sp.getViewport().setBackground(bg);
            applyTheme(sp.getViewport().getView(), bg, fg);
        }
    }

    /* ---------------- Notifications ---------------- */
    private void updateBadge() {
        notiBtn.setText("\uD83D\uDD14 " + NotificationManager.get().count());
    }

    private void showNotifications() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es","ES"));
        StringBuilder sb = new StringBuilder("<html>");
        boolean any = false;

        for (Event ev : allEvents) {
            if (NotificationManager.get().isNotified(ev.title)) {
                any = true;
                long days;
                try {
                    LocalDate d = LocalDate.parse(ev.date, fmt);
                    days = ChronoUnit.DAYS.between(today, d);
                } catch (Exception ex) {
                    days = Long.MIN_VALUE;
                }
                sb.append(ev.title).append(" – ");
                if (days<0)      sb.append("Ya pasó");
                else if (days==0)sb.append("Hoy");
                else             sb.append("Faltan ").append(days).append(" días");
                sb.append("<br>");
            }
        }
        if (!any) sb.append("No hay notificaciones seleccionadas.");
        sb.append("</html>");

        JOptionPane.showMessageDialog(this,
            sb.toString(),
            "Mis Notificaciones",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    /* ---------------- Utils ---------------- */
    private static ImageIcon loadScaled(String name,int w,int h){
        try(InputStream is=InicioFrame.class.getResourceAsStream(IMG_ROOT+name)){
            BufferedImage img=ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w,h,Image.SCALE_SMOOTH));
        } catch(Exception e){
            return new ImageIcon(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));
        }
    }
    private static BufferedImage loadBuffered(String name){
        try(InputStream is=InicioFrame.class.getResourceAsStream(IMG_ROOT+name)){
            return ImageIO.read(is);
        } catch(Exception e){
            return new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        }
    }
    private void openURL(String u){
        try{ Desktop.getDesktop().browse(new URI(u)); }catch(Exception ignored){}
    }
    private static class ImagePanel extends JPanel {
        private final Image img;
        ImagePanel(Image i){ img=i; }
        @Override protected void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(img,0,0,getWidth(),getHeight(),this);
        }
    }

    // ** Los mismos inner classes que en EventosFrame **
    private static class Event {
        String title, date, time, place, description, category;
        int duration;
        Event(String t,String d,String ti,String p,String desc,String cat,int du){
            this.title=t; this.date=d; this.time=ti;
            this.place=p; this.description=desc;
            this.category=cat; this.duration=du;
        }
    }
    private static class TempEvent {
        String titulo, descripcion, fecha, hora, lugar, categoria;
        int duracion;
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(InicioFrame::new);
    }
}
