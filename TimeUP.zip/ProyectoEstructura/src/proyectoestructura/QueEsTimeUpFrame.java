package proyectoestructura;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class QueEsTimeUpFrame extends JFrame {
    private static final String IMG_ROOT = "/images/";
    private static final String UNAB_LOGO = "logo_inferior.png";
    private static final String UNAB_NAME = "logito_1.png";
    private static final Color ORANGE = new Color(255, 130, 0);
    private static final Font TITLE_FONT = new Font("Open Sans", Font.BOLD, 30);
    private static final Font SECTION_FONT = new Font("Open Sans", Font.BOLD, 24);
    private static final Font BODY_FONT = new Font("Open Sans", Font.PLAIN, 14);

    public QueEsTimeUpFrame() {
        // Cierra MainApp si está abierto
        for (Window w : Window.getWindows()) {
            if (w instanceof MainApp) w.dispose();
        }

        setTitle("¿Qué es TimeUp?");
        setSize(1024, 720);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        add(createHeader(), BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 3, 0, ORANGE),
            new EmptyBorder(10, 20, 10, 20)
        ));

        // Logos UNAB
        JPanel logos = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        logos.setOpaque(false);
        logos.add(new JLabel(loadScaled(IMG_ROOT + UNAB_LOGO, 70, 70)));
        logos.add(new JLabel(loadScaled(IMG_ROOT + UNAB_NAME, 140, 45)));
        header.add(logos, BorderLayout.WEST);

        // Título centrado
        JLabel title = new JLabel("¿Qué es TimeUp?");
        // Ajuste de posición para alinear con títulos de sección
        title.setBorder(new EmptyBorder(0, -250, 0, 0));
        title.setFont(TITLE_FONT);
        title.setForeground(ORANGE);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        header.add(title, BorderLayout.CENTER);

        return header;
    }

// Sustituye el método createContent() por este:
private JPanel createContent() {
    JPanel content = new JPanel();
    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
    content.setBackground(Color.WHITE);
    content.setBorder(new EmptyBorder(20, 50, 20, 50));

    addSection(content, "¿Qué es?",
        "<html><div style='text-align:justify;'>TimeUP UNAB es una aplicación desarrollada por estudiantes de la Universidad Autónoma de Bucaramanga que permite a los usuarios gestionar de manera eficiente sus <b>horas libres académicas</b>. Su interfaz gráfica facilita la inscripción en eventos culturales, académicos o deportivos, mientras calcula automáticamente el progreso hacia el cumplimiento de los requisitos institucionales para la graduación.</div></html>");

    addSection(content, "🎯 Problemática",
        "<html><div style='text-align:justify;'>Actualmente, los estudiantes enfrentan dificultades para consultar sus horas en las plataformas existentes como <i>Mi Portal U</i> y <i>Cosmos</i>, que suelen presentar discrepancias y carecen de un diseño intuitivo. Esto genera desorganización, retrasos académicos y un aumento en la procrastinación.</div></html>");

    addSection(content, "🚀 Objetivo",
        "<html><div style='text-align:justify;'>El objetivo principal es brindar una herramienta moderna, accesible y visualmente agradable que permita a los estudiantes llevar un control claro de sus horas libres, participar en eventos y mantenerse motivados durante su proceso académico.</div></html>");

    addSectionList(content, "🔧 Funcionalidades Destacadas", new String[]{
        "📅 Agenda interactiva con eventos filtrables por categoría.",
        "🕒 Cálculo de horas acumuladas y horas faltantes.",
        "🔔 Recordatorios y notificaciones persistentes de eventos.",
        "🌗 Modo claro / oscuro con persistencia global.",
        "⭐ Calificación de eventos con reseñas estudiantiles.",
        "🧭 Mapa de eventos estilo campus virtual.",
        "📈 Simulador de horas faltantes según eventos seleccionados.",
        "🆘 Centro de soporte y reporte de problemas institucionales."
    });

    addSection(content, "📊 Impacto Esperado",
        "<html><div style='text-align:justify;'>TimeUP contribuirá directamente a mejorar la experiencia estudiantil, ayudando a planificar actividades, reducir el estrés académico y optimizar el cumplimiento de requisitos institucionales. A su vez, facilita a la universidad el seguimiento del progreso de cada estudiante.</div></html>");

    return content;
}


    private void addSection(JPanel parent, String titleText, String bodyText) {
        JLabel title = new JLabel(titleText);
        title.setFont(SECTION_FONT);
        title.setForeground(ORANGE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        parent.add(title);
        parent.add(Box.createVerticalStrut(8));

        JLabel body = new JLabel("<html><div style='text-align:center;'>" + bodyText + "</div></html>");
        body.setFont(BODY_FONT);
        body.setForeground(Color.DARK_GRAY);
        body.setAlignmentX(Component.CENTER_ALIGNMENT);
        body.setHorizontalAlignment(SwingConstants.CENTER);
        parent.add(body);
        parent.add(Box.createVerticalStrut(12));
    }

    private void addSectionList(JPanel parent, String titleText, String[] items) {
        JLabel title = new JLabel(titleText);
        title.setFont(SECTION_FONT);
        title.setForeground(ORANGE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        parent.add(title);
        parent.add(Box.createVerticalStrut(8));

        for (String item : items) {
            JLabel li = new JLabel("\u2022 " + item);
            li.setFont(BODY_FONT);
            li.setForeground(Color.DARK_GRAY);
            li.setAlignmentX(Component.CENTER_ALIGNMENT);
            li.setHorizontalAlignment(SwingConstants.CENTER);
            parent.add(li);
            parent.add(Box.createVerticalStrut(6));
        }
        parent.add(Box.createVerticalStrut(12));
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(10, 20, 10, 20));

        JButton btnVolver = new JButton("Volver");
        btnVolver.setFont(SECTION_FONT);
        btnVolver.setBackground(ORANGE);
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.setBorder(new LineBorder(ORANGE.darker(), 2, true));
        btnVolver.addActionListener(e -> {
            dispose();
            new MainApp();
        });
        footer.add(btnVolver);

        return footer;
    }

    private static ImageIcon loadScaled(String path, int w, int h) {
        try (InputStream is = QueEsTimeUpFrame.class.getResourceAsStream(path)) {
            if (is == null) throw new IOException("Recurso no encontrado: " + path);
            BufferedImage img = ImageIO.read(is);
            Image scaled = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
            return new ImageIcon();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(QueEsTimeUpFrame::new);
    }
}
