package proyectoestructura;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import proyectoestructura.ThemeManager;
import proyectoestructura.NotificationManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MiAgendaFrame extends JFrame {
    private static final String IMG_ROOT = "/images/";
    private boolean darkMode;
    private YearMonth currentMonth = YearMonth.now();
    private JPanel calendarPanel;
    private JLabel monthLabel;
    private Map<LocalDate, java.util.List<Evento>> eventos = new HashMap<>();
    private JPanel eventDetailPanel;
    private JTextArea eventDetailArea;
    private JButton notiBtn;
    private Map<String,String> titleToDate = new HashMap<>();

    public MiAgendaFrame() {
        super("Mi Agenda - Unab TimeUp");
        setMinimumSize(new Dimension(1024, 640));
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        loadEventsFromJson();

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        // Inicializar tema y notificaciones
        darkMode = ThemeManager.isDarkMode();
        updateBadge();
        applyTheme(getContentPane(),
            darkMode ? new Color(45,45,45) : new Color(245,245,245),
            darkMode ? Color.WHITE : Color.DARK_GRAY
        );

        // Forzar que los eventos se marquen al inicio
        renderCalendar();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    /** Carga eventos y fechas desde JSON en /resources/eventos.json */
    private void loadEventsFromJson() {
        try (InputStream is = getClass().getResourceAsStream("/resources/eventos.json");
             Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            java.util.List<TempEvent> temp = new Gson()
                .fromJson(r, new TypeToken<java.util.List<TempEvent>>(){}.getType());
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es","ES"));
            for (TempEvent t : temp) {
                titleToDate.put(t.titulo, t.fecha);
                LocalDate d = LocalDate.parse(t.fecha, fmt);
                eventos.computeIfAbsent(d, k->new java.util.ArrayList<>())
                       .add(new Evento(t.titulo, t.lugar, t.hora, t.descripcion, t.categoria, t.duracion));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245,245,245));

        // Logo izquierda
        JPanel west = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        west.setOpaque(false);
        west.add(new JLabel(loadScaled("logo_inferior.png",100,100)));
        west.add(new JLabel(loadScaled("logito_1.png",200,90)));
        header.add(west, BorderLayout.WEST);

        // Menú central
        String[] names = {"Inicio","Eventos","Historial","Mi agenda","Soportes"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER,20,15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new java.awt.Font("SansSerif",java.awt.Font.BOLD,14));
            b.setBackground(new Color(240,240,240));
            b.setPreferredSize(new Dimension(160,40));
            b.setBorder(new LineBorder(new Color(200,200,200),1,true));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            switch (n) {
                case "Inicio":    b.addActionListener(e->{ new InicioFrame().setVisible(true); dispose(); }); break;
                case "Eventos":   b.addActionListener(e->{ new EventosFrame().setVisible(true); dispose(); }); break;
                case "Historial": b.addActionListener(e->{ new HistorialFrame().setVisible(true); dispose(); }); break;
                case "Mi agenda": b.setEnabled(false); break;
                case "Soportes":  b.addActionListener(e->{ new SoportesFrame().setVisible(true); dispose(); }); break;
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        // Derecha: notificaciones, modo oscuro y perfil
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,20,12));
        right.setOpaque(false);

        notiBtn = new JButton("\uD83D\uDD14 0");
        notiBtn.setFont(new java.awt.Font("SansSerif",java.awt.Font.BOLD,12));
        notiBtn.setContentAreaFilled(false);
        notiBtn.setBorder(null);
        notiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notiBtn.addActionListener(e-> showNotifications());
        right.add(notiBtn);

                JButton profileBtn = new JButton(loadScaled("perfil.png",30,30));
        profileBtn.setContentAreaFilled(false);
        profileBtn.setBorder(null);
        profileBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        profileBtn.addActionListener(e->{ new PerfilFrame().setVisible(true); dispose(); });
        right.add(profileBtn);
        
        JButton darkBtn = new JButton(loadScaled("modo_oscuro.png",30,30));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e-> {
            toggleDarkMode();
            renderCalendar();
        });
        right.add(darkBtn);



        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());

        // Calendario izquierda
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(darkMode?new Color(45,45,45):Color.WHITE);
        left.setPreferredSize(new Dimension(getWidth()/2, getHeight()));

        JPanel calendario = new JPanel(new BorderLayout());
        calendario.setBackground(left.getBackground());

        // Controles mes
        JPanel controls = new JPanel(new BorderLayout());
        controls.setBackground(left.getBackground());
        JButton prev = new JButton(loadScaled("flecha_izq.png",30,30));
        prev.setContentAreaFilled(false); prev.setBorder(null);
        prev.addActionListener(e->{ currentMonth = currentMonth.minusMonths(1); renderCalendar(); });
        JButton next = new JButton(loadScaled("flecha_dere.png",30,30));
        next.setContentAreaFilled(false); next.setBorder(null);
        next.addActionListener(e->{ currentMonth = currentMonth.plusMonths(1); renderCalendar(); });
        monthLabel = new JLabel("", JLabel.CENTER);
        monthLabel.setFont(new java.awt.Font("SansSerif",java.awt.Font.BOLD,24));
        controls.add(prev,BorderLayout.WEST);
        controls.add(monthLabel,BorderLayout.CENTER);
        controls.add(next,BorderLayout.EAST);

        calendarPanel = new JPanel(new GridLayout(0,7));
        calendarPanel.setBackground(left.getBackground());

        calendario.add(controls,BorderLayout.NORTH);
        calendario.add(calendarPanel,BorderLayout.CENTER);

        left.add(calendario,BorderLayout.CENTER);

        // Detalle evento derecha
        eventDetailPanel = new JPanel(new BorderLayout());
        eventDetailPanel.setPreferredSize(new Dimension(getWidth()/2-40, getHeight()));
        eventDetailPanel.setBackground(darkMode?new Color(45,45,45):Color.WHITE);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
        topPanel.setBackground(eventDetailPanel.getBackground());
        for (int i=0; i<4; i++) {
            JLabel lbl = new JLabel();
            lbl.setFont(new java.awt.Font("SansSerif",java.awt.Font.BOLD,16));
            lbl.setForeground(darkMode?Color.WHITE:Color.DARK_GRAY);
            lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            topPanel.add(Box.createVerticalStrut(5));
            topPanel.add(lbl);
        }

        eventDetailArea = new JTextArea();
        eventDetailArea.setEditable(false);
        eventDetailArea.setLineWrap(true);
        eventDetailArea.setWrapStyleWord(true);
        eventDetailArea.setFont(new java.awt.Font("SansSerif",java.awt.Font.PLAIN,14));
        // applyTheme hará su fondo/texto
        JScrollPane scrollDesc = new JScrollPane(eventDetailArea);
        scrollDesc.setBorder(null);
        scrollDesc.getViewport().setBackground(eventDetailPanel.getBackground());

        eventDetailPanel.add(topPanel,BorderLayout.NORTH);
        eventDetailPanel.add(scrollDesc,BorderLayout.CENTER);

        center.add(left,BorderLayout.WEST);
        center.add(Box.createRigidArea(new Dimension(20,0)),BorderLayout.CENTER);
        center.add(eventDetailPanel,BorderLayout.EAST);
        return center;
    }

    private void renderCalendar() {
        calendarPanel.removeAll();
        Locale loc = new Locale("es","ES");
        String[] dias = {"Lun","Mar","Mié","Jue","Vie","Sáb","Dom"};
        for (String dia : dias) {
            JLabel lbl = new JLabel(dia,JLabel.CENTER);
            lbl.setFont(new java.awt.Font("SansSerif",java.awt.Font.BOLD,16));
            lbl.setForeground(darkMode?Color.WHITE:Color.DARK_GRAY);
            calendarPanel.add(lbl);
        }
        String mes = currentMonth.getMonth().getDisplayName(TextStyle.FULL,loc);
        mes = mes.substring(0,1).toUpperCase()+mes.substring(1);
        monthLabel.setText(mes + " " + currentMonth.getYear());
        monthLabel.setForeground(darkMode?Color.WHITE:Color.DARK_GRAY);

        int offset = currentMonth.atDay(1).getDayOfWeek().getValue() % 7;
        for(int i=0;i<offset;i++) calendarPanel.add(new JLabel(""));
        for(int d=1; d<=currentMonth.lengthOfMonth(); d++){
            LocalDate date = currentMonth.atDay(d);
            JButton btn = new JButton(String.valueOf(d));
            btn.setOpaque(true);
            btn.setBorder(null);
            btn.setBackground(darkMode?new Color(60,60,60):Color.WHITE);
            btn.setForeground(eventos.containsKey(date)?Color.RED:
                              darkMode?Color.WHITE:Color.BLACK);
            btn.addActionListener(e-> showDetails(date));
            calendarPanel.add(btn);
        }
        calendarPanel.revalidate();
        calendarPanel.repaint();
    }

    private void showDetails(LocalDate date) {
        java.util.List<Evento> list = eventos.getOrDefault(date, Collections.<Evento>emptyList());
        if (list.isEmpty()) {
            eventDetailArea.setText("No hay eventos.");
            return;
        }
        Evento ev = list.get(0);
        JPanel top = (JPanel)eventDetailPanel.getComponent(0);
        ((JLabel)top.getComponent(1)).setText("Título: "+ev.titulo);
        ((JLabel)top.getComponent(3)).setText("Lugar: "+ev.lugar);
        ((JLabel)top.getComponent(5)).setText("Hora: "+ev.hora);
        eventDetailArea.setText(ev.descripcion);
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245,245,245));

        JLabel logo = new JLabel(loadScaled("logo_inferior.png",60,60));
        JLabel legal = new JLabel(loadScaled("texto_largo.png",260,60));
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        left.setOpaque(false);
        left.add(logo);
        left.add(legal);
        footer.add(left, BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1,2,100,0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes","https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales","https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB","https://repository.unab.edu.co"},
            {"Bibliotecas UNAB","https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube","https://youtube.com/@unabeduco"},
            {"LinkedIn","https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter","https://twitter.com/unab_online"},
            {"Instagram","https://instagram.com/unab_online"},
            {"Facebook","https://facebook.com/unab.online"}
        }));
        footer.add(cols, BorderLayout.CENTER);

        return footer;
    }

    private JPanel buildLinkColumn(String title, String[][] data) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col,BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new java.awt.Font("Open Sans",java.awt.Font.BOLD,12));
        t.setForeground(new Color(164,164,164));
        col.add(t); col.add(Box.createVerticalStrut(8));
        for (String[] d : data) {
            JLabel l = new JLabel(d[0]);
            l.setFont(new java.awt.Font("Open Sans",java.awt.Font.PLAIN,12));
            l.setForeground(new Color(164,164,164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            l.addMouseListener(new MouseAdapter(){
                public void mouseClicked(MouseEvent e){ openURL(d[1]); }
                public void mouseEntered(MouseEvent e){ l.setForeground(new Color(120,120,120)); }
                public void mouseExited(MouseEvent e){ l.setForeground(new Color(164,164,164)); }
            });
            col.add(l); col.add(Box.createVerticalStrut(4));
        }
        return col;
    }

    private void updateBadge(){
        notiBtn.setText("\uD83D\uDD14 "+NotificationManager.get().count());
    }
    private void showNotifications(){
        LocalDate today = LocalDate.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es","ES"));
        StringBuilder sb = new StringBuilder("<html>");
        for (String t : NotificationManager.get().getNotifiedTitles()) {
            long d;
            try { d = ChronoUnit.DAYS.between(today, LocalDate.parse(titleToDate.get(t), fmt)); }
            catch (Exception ex) { d = Long.MIN_VALUE; }
            sb.append(t).append(" - ");
            if (d < 0)      sb.append("Ya pasó");
            else if (d == 0) sb.append("Hoy");
            else            sb.append("Faltan ").append(d).append(" días");
            sb.append("<br>");
        }
        sb.append("</html>");
        JOptionPane.showMessageDialog(this, sb.toString(), "Notificaciones", JOptionPane.INFORMATION_MESSAGE);
    }

    private void toggleDarkMode(){
        darkMode = !darkMode;
        ThemeManager.setDarkMode(darkMode);
        applyTheme(getContentPane(),
            darkMode?new Color(45,45,45):new Color(245,245,245),
            darkMode?Color.WHITE:Color.DARK_GRAY
        );
    }

    private void applyTheme(Component c, Color bg, Color fg){
        if (c instanceof JPanel) {
            c.setBackground(bg);
            for (Component ch : ((JPanel)c).getComponents()) applyTheme(ch,bg,fg);
        } else if (c instanceof JLabel) {
            ((JLabel)c).setForeground(fg);
        } else if (c instanceof JButton) {
            ((JButton)c).setBackground(darkMode?new Color(70,70,70):new Color(240,240,240));
            ((JButton)c).setForeground(fg);
        } else if (c instanceof JTextArea) {
            ((JTextArea)c).setBackground(bg);
            ((JTextArea)c).setForeground(fg);
        }
    }

    private static ImageIcon loadScaled(String name,int w,int h){
        try (InputStream is = MiAgendaFrame.class.getResourceAsStream(IMG_ROOT + name)) {
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w,h,Image.SCALE_SMOOTH));
        } catch (Exception e) {
            return new ImageIcon(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));
        }
    }

    private void openURL(String url){
        try { Desktop.getDesktop().browse(new URI(url)); }
        catch (Exception ignored){}
    }

    private static class TempEvent {
        String titulo, descripcion, fecha, hora, lugar, categoria;
        int duracion;
    }

    private static class Evento {
        String titulo,lugar,hora,descripcion,categoria; int duracion;
        Evento(String t,String l,String h,String d,String c,int dur){
            titulo=t; lugar=l; hora=h; descripcion=d; categoria=c; duracion=dur;
        }
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(MiAgendaFrame::new);
    }
}
