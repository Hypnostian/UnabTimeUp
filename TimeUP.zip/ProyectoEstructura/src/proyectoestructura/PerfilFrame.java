package proyectoestructura;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;
import proyectoestructura.ThemeManager;

public class PerfilFrame extends JFrame {
    private static final String IMG_ROOT = "/images/";
    private boolean darkMode;
    private JButton notiBtn;
    private final Map<String,String> titleToDate = new HashMap<>();
    private JPanel sidebar;  // para ajuste dinámico

    public PerfilFrame() {
        super("Perfil - Unab TimeUp");
        setMinimumSize(new Dimension(1024, 640));
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        loadEventDates();

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        // recarga contador y tema
        updateBadge();
        darkMode = ThemeManager.isDarkMode();
        Color bg = darkMode ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = darkMode ? Color.WHITE       : Color.DARK_GRAY;
        applyTheme(getContentPane(), bg, fg);

        // ajustar ancho de sidebar según ancho del Frame
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int frameW = getWidth();
                // dinámico: 1/4 del ancho de la ventana, entre 180 y 280 px
                int newW = frameW / 4;
                newW = Math.max(180, Math.min(280, newW));
                sidebar.setPreferredSize(new Dimension(newW, 0));
                revalidate();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    /** Carga mapa título→fecha desde JSON */
    private void loadEventDates() {
        try (InputStream is = getClass().getResourceAsStream("/resources/eventos.json");
             Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            List<TempEvent> temp = new Gson()
              .fromJson(r, new TypeToken<List<TempEvent>>() {}.getType());
            for (TempEvent e : temp) titleToDate.put(e.titulo, e.fecha);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /* --------------- HEADER --------------- */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(245,245,245));

        // LOGO IZQ
        JPanel west = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        west.setOpaque(false);
        west.add(new JLabel(loadScaled("logo_inferior.png",100,100)));
        west.add(new JLabel(loadScaled("logito_1.png",200,90)));
        header.add(west, BorderLayout.WEST);

        // MENÚ CENTRAL
        String[] names = {"Inicio","Eventos","Historial","Mi agenda","Soportes"};
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER,20,15));
        bar.setOpaque(false);
        for (String n : names) {
            JButton b = new JButton(n);
            b.setFont(new Font("SansSerif",Font.BOLD,14));
            b.setPreferredSize(new Dimension(160,40));
            b.setBackground(new Color(240,240,240));
            b.setBorder(new LineBorder(new Color(200,200,200),1,true));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            switch (n) {
                case "Inicio":    b.addActionListener(e->{ new InicioFrame().setVisible(true); dispose(); }); break;
                case "Eventos":   b.addActionListener(e->{ new EventosFrame().setVisible(true); dispose(); }); break;
                case "Historial": b.addActionListener(e->{ new HistorialFrame().setVisible(true); dispose(); }); break;
                case "Mi agenda": b.addActionListener(e->{ new MiAgendaFrame().setVisible(true); dispose(); }); break;
                case "Soportes":  b.addActionListener(e->{ new SoportesFrame().setVisible(true); dispose(); }); break;
            }
            bar.add(b);
        }
        header.add(bar, BorderLayout.CENTER);

        // PANEL DERECHO: campana + modo oscuro
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,20,12));
        right.setOpaque(false);

        notiBtn = new JButton("\uD83D\uDD14 0");
        notiBtn.setFont(new Font("SansSerif",Font.BOLD,12));
        notiBtn.setContentAreaFilled(false);
        notiBtn.setBorder(null);
        notiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notiBtn.addActionListener(e-> showNotifications());
        right.add(notiBtn);

        JButton darkBtn = new JButton(loadScaled("modo_oscuro.png",30,30));
        darkBtn.setContentAreaFilled(false);
        darkBtn.setBorder(null);
        darkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        darkBtn.addActionListener(e-> toggleDarkMode());
        right.add(darkBtn);

        header.add(right, BorderLayout.EAST);
        return header;
    }

    /* --------------- CENTER --------------- */
    private JPanel buildCenter() {
        // SALUDO + separador
        JLabel saludo = new JLabel("¡Hola, Karol!");
        saludo.setFont(new Font("SansSerif",Font.BOLD,40));
        saludo.setBorder(BorderFactory.createEmptyBorder(20,20,10,0));
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(new Color(245,245,245));
        top.add(saludo,BorderLayout.WEST);
        top.add(new JSeparator(),BorderLayout.SOUTH);

        // SIDEBAR IZQ
        Color orange = new Color(0xFF9D56), hover = new Color(230,140,0);
        JPanel left = new JPanel();
        left.setName("sidebar");
        left.setBackground(orange);
        left.setPreferredSize(new Dimension(280,0));
        left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS));
        sidebar = left;  // guardamos referencia

        left.add(Box.createVerticalStrut(10));
        // avatar centrado
        JLabel avatar = new JLabel(loadScaled("peerfil.png",150,150));
        avatar.setAlignmentX(Component.CENTER_ALIGNMENT);
        left.add(avatar);
        left.add(Box.createVerticalStrut(5));

        JLabel nombre = new JLabel("Karol Ramirez Salazar");
        nombre.setFont(new Font("SansSerif",Font.BOLD,20));
        nombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        left.add(nombre);

        String[][] items = {
            {"Currículo y estado","https://estudiantes.unab.edu.co/StudentSelfService/ssb/studentProfile"},
            {"Horario","https://registro.unab.edu.co/StudentRegistrationSsb/ssb/registrationHistory/registrationHistory"},
            {"Enlaces adicionales","https://unab.edu.co/contactanos/"},
            {"Ver calificaciones","https://estudiantes.unab.edu.co/StudentSelfService/ssb/studentGrades"},
            {"Histórico académico","https://estudiantes.unab.edu.co/StudentSelfService/ssb/academicTranscript#!/:transcriptLevel/:transcriptType"}
        };
        for (String[] it : items) {
            left.add(Box.createVerticalStrut(10));
            JButton btn = new JButton(it[0]);
            btn.setFont(new Font("SansSerif",Font.PLAIN,18));
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE,50));
            btn.setBackground(orange);
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.setBorderPainted(false);
            btn.setFocusPainted(false);
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){ btn.setBackground(hover); }
                public void mouseExited(MouseEvent e){ btn.setBackground(orange); }
            });
            btn.addActionListener(e-> {
                try{ Desktop.getDesktop().browse(new URI(it[1])); }
                catch(Exception ex){ JOptionPane.showMessageDialog(this,"No se pudo abrir: "+it[1]); }
            });
            left.add(btn);
        }

        // PANEL DERECHO (centron/centrob)
        BackgroundPanel right = new BackgroundPanel();
        right.setLayout(new BorderLayout());
        right.setOpaque(false);

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS));
        info.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        right.add(info, BorderLayout.CENTER);

        JPanel content = new JPanel(new BorderLayout());
        content.add(left,BorderLayout.WEST);
        content.add(right,BorderLayout.CENTER);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.add(top,BorderLayout.NORTH);
        wrapper.add(content,BorderLayout.CENTER);
        return wrapper;
    }

    /** Fondo dinámico centron/centrob */
    private class BackgroundPanel extends JPanel {
        BufferedImage light, dark;
        BackgroundPanel(){
            try(InputStream a=getClass().getResourceAsStream(IMG_ROOT+"centron.png");
                InputStream b=getClass().getResourceAsStream(IMG_ROOT+"centrob.png")) {
                light = ImageIO.read(a);
                dark  = ImageIO.read(b);
            } catch(Exception e){
                light = dark = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
            }
        }
        @Override protected void paintComponent(Graphics g){
            super.paintComponent(g);
            BufferedImage img = ThemeManager.isDarkMode() ? dark : light;
            int w = Math.min(getWidth(), (int)(getHeight()*1.6));
            int h = Math.min(getHeight(), (int)(getWidth()/1.6));
            g.drawImage(img,0,0,w,h,null);
        }
    }

    /* --------------- FOOTER --------------- */
    private JPanel buildFooter(){
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(245,245,245));
        JPanel L = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        L.setOpaque(false);
        L.add(new JLabel(loadScaled("logo_inferior.png",60,60)));
        L.add(new JLabel(loadScaled("texto_largo.png",260,60)));
        footer.add(L,BorderLayout.WEST);

        JPanel cols = new JPanel(new GridLayout(1,2,100,0));
        cols.setOpaque(false);
        cols.add(buildLinkColumn("Enlaces de interés", new String[][]{
            {"Preguntas frecuentes","https://tema.unab.edu.co/mod/forum/view.php?id=1"},
            {"Recursos digitales","https://unab.edu.co/innova/recursos-y-ayudas-profesores/"},
            {"Repositorio UNAB","https://repository.unab.edu.co"},
            {"Sistema de bibliotecas UNAB","https://unab.edu.co/sistema-de-bibliotecas-unab/"}
        }));
        cols.add(buildLinkColumn("Redes sociales", new String[][]{
            {"Youtube","https://www.youtube.com/@unabeduco"},
            {"Linkedin","https://co.linkedin.com/school/universidad-autonoma-de-bucaramanga/"},
            {"Twitter","https://twitter.com/unab_online"},
            {"Instagram","https://www.instagram.com/unab_online/"},
            {"Facebook","https://www.facebook.com/unab.online/"}
        }));
        footer.add(cols,BorderLayout.CENTER);
        return footer;
    }

    private JPanel buildLinkColumn(String title,String[][] data){
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col,BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Open Sans",Font.BOLD,12));
        t.setForeground(new Color(164,164,164));
        col.add(t); col.add(Box.createVerticalStrut(8));
        for(String[] d:data){
            JLabel l = new JLabel(d[0]);
            l.setFont(new Font("Open Sans",Font.PLAIN,12));
            l.setForeground(new Color(164,164,164));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            l.addMouseListener(new MouseAdapter(){
                public void mouseClicked(MouseEvent e){ openURL(d[1]); }
                public void mouseEntered(MouseEvent e){ l.setForeground(new Color(120,120,120)); }
                public void mouseExited(MouseEvent e){ l.setForeground(new Color(164,164,164)); }
            });
            col.add(l); col.add(Box.createVerticalStrut(4));
        }
        return col;
    }

    /* -------- DARK MODE -------- */
    private void toggleDarkMode(){
        darkMode = !ThemeManager.isDarkMode();
        ThemeManager.setDarkMode(darkMode);
        Color bg = darkMode ? new Color(45,45,45) : new Color(245,245,245);
        Color fg = darkMode ? Color.WHITE       : Color.DARK_GRAY;
        applyTheme(getContentPane(),bg,fg);
        repaint();
    }

    private void applyTheme(Component c,Color bg,Color fg){
        if(c instanceof JPanel && !"sidebar".equals(c.getName())){
            c.setBackground(bg);
            for(Component ch:((JPanel)c).getComponents()) applyTheme(ch,bg,fg);
        } else if(c instanceof JLabel){
            ((JLabel)c).setForeground(fg);
        } else if(c instanceof JButton){
            ((JButton)c).setForeground(fg);
            Container p = ((JButton)c).getParent();
            if(p==null || !"sidebar".equals(p.getName()))
                ((JButton)c).setBackground(darkMode?new Color(70,70,70):new Color(240,240,240));
        }
    }

    /* ---- NOTIFICACIONES ---- */
    private void updateBadge(){
        notiBtn.setText("\uD83D\uDD14 "+NotificationManager.get().count());
    }
    private void showNotifications(){
        Set<String> ts = NotificationManager.get().getNotifiedTitles();
        if(ts.isEmpty()){
            JOptionPane.showMessageDialog(this,"No hay notificaciones.","Notificaciones",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        LocalDate today = LocalDate.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy",new Locale("es","ES"));
        StringBuilder sb = new StringBuilder("<html>");
        for(String t:ts){
            String d = titleToDate.getOrDefault(t,"");
            long days;
            try{ days = ChronoUnit.DAYS.between(today,LocalDate.parse(d,fmt)); }
            catch(Exception x){ days=Long.MIN_VALUE; }
            sb.append(t).append(" - ");
            if(days<0)       sb.append("Ya pasó");
            else if(days==0) sb.append("Hoy");
            else             sb.append("Faltan ").append(days).append(" días");
            sb.append("<br>");
        }
        sb.append("</html>");
        JOptionPane.showMessageDialog(this,sb.toString(),"Mis Notificaciones",JOptionPane.INFORMATION_MESSAGE);
    }

    /* ------ UTILS ------ */
    private static ImageIcon loadScaled(String name,int w,int h){
        try(InputStream is=PerfilFrame.class.getResourceAsStream(IMG_ROOT+name)){
            BufferedImage img = ImageIO.read(is);
            return new ImageIcon(img.getScaledInstance(w,h,Image.SCALE_SMOOTH));
        }catch(Exception e){
            return new ImageIcon(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));
        }
    }
    private void openURL(String u){
        try{ Desktop.getDesktop().browse(new URI(u)); }catch(Exception ignored){}
    }

    private static class TempEvent {
        String titulo,descripcion,fecha,hora,lugar,categoria;
        int duracion;
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(PerfilFrame::new);
    }
}
